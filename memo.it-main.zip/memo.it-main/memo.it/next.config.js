/** @type {import('next').NextConfig} */

const nextSafe = require('next-safe')
const headers = nextSafe({
  contentSecurityPolicy: {
    'script-src': `'self' 'unsafe-inline' 'unsafe-eval'`
  },
  permissionsPolicy: {
    'clipboard-write': 'self'
  }
})

const config = {
    async headers() {
        return [
          {
            source: '/:path*',
            headers: headers
          },
        ]
      },    
}

if (process.env.NODE_ENV === 'production') config.output = 'standalone'

module.exports = config