import { compress, decompress } from "../lib/compression"


test('compress should work with any string value', () => {
    expect(() => { compress('text') }).not.toThrowError()
})

test('compression should be reversible', () => {
    const initial = 'text'
    const compressed = compress(initial)
    const decompressed = decompress(compressed)

    expect(initial).toBe(decompressed)
})

test('compression should be reversible for random values', () => {
    const string1 = Math.random().toString(16).slice(2, 8)
    const string2 = Math.random().toString(16).slice(2, 8)

    const compressed1 = compress(string1)
    const compressed2 = compress(string2)

    expect(decompress(compressed1) + decompress(compressed2)).toBe(string1 + string2)
})

test('decompression should return empty string if value is invalid', () => {
    expect(decompress('c')).toBe('')
})