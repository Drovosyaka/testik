import Link from "next/link";

export default function Home(){
    return (
        <main className="flex min-h-screen flex-col items-center justify-between p-24">
            <h1>&quot;Memo it&quot; is a stateless notes app. It does not collect any data you input, all the notes are stored in link.</h1>
            <h2>Do not use it for passwords!</h2>
            <Link href="/c">Create a memo</Link>
        </main>
    )
}