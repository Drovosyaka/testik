import Editor from "@/components/Editor";
import { decompress } from "@/lib/compression";
import Link from "next/link";
import { notFound } from 'next/navigation'

export default function Memo(props: { params: { memo: string } }) {
  const decompressed = decompress(props.params.memo)
  // redirect to 404 if invalid
  if (props.params.memo !== 'c' && decompressed === '') notFound()

  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24">
      <Link href="/">Home</Link>
      <br />
      <Editor initialText={decompressed}/>
    </main>
  )
}
