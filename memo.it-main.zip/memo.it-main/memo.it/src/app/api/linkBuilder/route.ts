import { compress } from '@/lib/compression'
import { NextRequest, NextResponse } from 'next/server'

 
export async function POST(request: NextRequest){
  const memo: { memo: string } = await request.json()
  const url = new URL(
    compress(memo.memo), request.headers.get('Origin') ?? 'http://localhost'
  )
 
  return NextResponse.json({url: url})
}
