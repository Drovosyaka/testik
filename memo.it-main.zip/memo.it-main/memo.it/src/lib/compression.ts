import zlib from 'zlib'

export function compress(text: string): string{
    return zlib.brotliCompressSync(text).toString('base64url')
}

export function decompress(text: string): string{
    try{
        return zlib.brotliDecompressSync(Buffer.from(text, 'base64url')).toString()
    }
    catch{
        return ''
    }
}