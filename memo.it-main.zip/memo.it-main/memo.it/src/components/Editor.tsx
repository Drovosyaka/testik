'use client'

import { ChangeEvent, useState } from "react"


interface editorProps{
    initialText: string
}

export default function Editor(props: editorProps){
    const [text, setText] = useState(props.initialText)
    const updateText = (e: ChangeEvent<HTMLTextAreaElement>) => {
        setText(e.target.value)
    }
    const copyLink = async () => {
        const response = await fetch('api/linkBuilder', {
            method: 'POST',
            body: JSON.stringify({ memo: text })
        })
        const data = await response.json()

        try{
            navigator.clipboard.writeText(data.url)
        }
        catch{
            alert('copy only works for https website. You can share the note by copying the address')
            window.location = data.url
        }
    } 


    return (
        <>
            <textarea rows={30} cols={40} defaultValue={text} onChange={updateText}/>
            <br />
            <button onClick={copyLink} type="button">Copy</button>
        </>
    )
}