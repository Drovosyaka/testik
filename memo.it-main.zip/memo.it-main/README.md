# Memo it

This is a [Next.js](https://nextjs.org/) note app bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

## Development

Check memo.it/README.md

## Docker

The project uses 2 dockerfiles:

- "Dockerfile" is a minimized container. It is built only for release.

- "Dockerfile-debug" is the equivalent of the previous container in which it is possible to run tests.

To run app:
```bash
docker compose build app
docker compose up app
```
To run tests:
```bash
docker compose build tests
docker compose up tests
```